package web_7051cem.model;

public class Cart_Details extends Product_Details{
	
	private int quan;

	public Cart_Details() {}

	public int getQuan() {
		return quan;
	}

	public void setQuan(int quan) {
		this.quan = quan;
	}
	
	

}
